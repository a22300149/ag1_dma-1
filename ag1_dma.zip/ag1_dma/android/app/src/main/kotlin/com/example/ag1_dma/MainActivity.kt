package com.example.ag1_dma

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
